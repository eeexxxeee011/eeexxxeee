---
title: Cloud
emoji: 📚
colorFrom: pink
colorTo: yellow
sdk: docker
pinned: false
app_port: 8080
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
